package com.selenium;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Unit test for simple App.
 */
public class LoginTest 
{
    WebDriver driver = new ChromeDriver();


    @Test
    public void testLoginOk() {
        System.out.println("testLoginOk");
        String baseUrl = "https://bonigarcia.dev/selenium-webdriver-java/login-form.html";
        driver.get(baseUrl);
        System.out.println(driver.getCurrentUrl());

        driver.findElement(By.id("username")).sendKeys("user");
        driver.findElement(By.id("password")).sendKeys("user");
        driver.findElement(By.tagName("button")).click();

        System.out.println(driver.getCurrentUrl());
        //
        assertTrue(driver.findElement(By.id("success")).isDisplayed());
        assertEquals(driver.findElement(By.id("success")).getText(), "Login successful");
    }

    @Test
    public void testLoginNotOk() {
        System.out.println("testLoginNotOk");
        String baseUrl = "https://bonigarcia.dev/selenium-webdriver-java/login-form.html";
        driver.get(baseUrl);
        System.out.println(driver.getCurrentUrl());

        driver.findElement(By.id("username")).sendKeys("user");
        driver.findElement(By.id("password")).sendKeys("bad password");
        driver.findElement(By.className("mt-2")).click();
        System.out.println(driver.getCurrentUrl());

        assertTrue(driver.findElement(By.id("invalid")).isDisplayed());
    }
}
