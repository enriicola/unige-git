<html>

<header>
    <title> Modifica form con il settaggio dei cookie </title>
</header>

<body>


    <?php

        if (isset($_POST['btnsubmit'])) {
            mysetCookie();
        }

        function mySetCookie() {
            setcookie("ColorTextCookie", $_POST['color1']);
            setcookie("ColorBackgroundCookie", $_POST['color2']);
            setcookie("FontTextCookie", $_POST['select']);
            header("Location: index.php");
        }
    ?>

    <div  style="position: absolute; top:350px; right:600px">
        <fieldset class="noborder">                
            <form method="POST">
                <div> text color: <input type="color" id="color1" name="color1" /> </div>
                <div> backgorund: <input type="color" id="color2" name="color2" /> </div>
                <div> 
                    text font: <select id="select" name="select">
                        <option>Choose an option</option>
                        <option value="htmlTimes New Roman">Times New Roman</option>
                        <option value=" Arial "> Arial </option>
                    </select> 
                </div>
                
                <div> <button type="submit" name="btnsubmit" id="btnsubmit"> Submit </button> </div>
            </form>
		</fieldset>
    </div>

</body>


</html>