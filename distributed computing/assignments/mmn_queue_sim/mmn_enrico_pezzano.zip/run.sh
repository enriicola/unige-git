sh run_weibull.sh

sh run_round_robin.sh