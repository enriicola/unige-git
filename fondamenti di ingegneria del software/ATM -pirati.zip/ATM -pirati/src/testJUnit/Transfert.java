package testJUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import store.Account;
import store.BankDatabase;
import visualization.KeyPadVis;
import visualization.ScreenVis;

import boundary.Keypad;
import boundary.Screen;
import junit.framework.*;
import static org.easymock.classextension.EasyMock.*;
import static org.easymock.EasyMock.*;



public class Transfert extends TestCase {
	
	private int userAccountNumber; 
	private Screen atmScreen;
	private BankDatabase atmBankDatabase; 
	private Keypad atmKeypad;
	
	@Before
	public void setUp() throws Exception {
		Account accounts[] = new Account[ 3 ];
		accounts[ 0 ] = new Account( 12345, 54321, 1000.0, 1200.0 );
		accounts[ 1 ] = new Account( 98765, 56789, 200.0, 200.0 ); 
		accounts[ 2 ] = new Account( 56789, 98765, 100000.00, 999999.99 ); 
		atmBankDatabase=new BankDatabase(accounts);
		atmScreen=new Screen(new ScreenVis());
		atmKeypad=createMock(Keypad.class);
		expect(atmKeypad.getVis()).andReturn(new KeyPadVis()).times(0,1);
	}

	@After
	public void tearDown() throws Exception {
		verify(atmKeypad);
	}
	

	@Test//test transazione terminata correttamente
	public void testExecuteOkNormal() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(900.0, userAvailableBalance);
		assertEquals(1100.0, userTotalBalance);
		assertEquals(300.0, targetTotalBalance);
		
	}
	
	@Test//test transazione cancellata durante inserimento numero conto destinatario
	public void testExecuteAbortUser() {
		
		userAccountNumber=12345;
		int targetAccountNumber=-2;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		
	}
	
	@Test//test transazione terminata per aver inserito un numero di conto inesistente
	public void testExecuteKoUser() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98766;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);

		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		
	}
	
	@Test//test transazione terminata per aver messo il proprio conto come destinatario
	public void testExecuteKoSameUser() {
		
		userAccountNumber=12345;
		int targetAccountNumber=12345;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);

		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		
	}
	
	@Test//test transazione cancellata durante la scelta dell'importo
	public void testExecuteAbortCash() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(-2);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		assertEquals(200.0, targetTotalBalance);
		
	}
	
	@Test //test transazione terminata per aver immesso un importo superiore a quello disponibile
	public void testExecuteKoCashBorderline() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(100001);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		assertEquals(200.0, targetTotalBalance);
		
	}
	
	@Test //test transazione terminata correttamente trasferendo tutti i soldi disponibili
	public void testExecuteOkCashBorderline() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(100000);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(0.0, userAvailableBalance);
		assertEquals(200.0, userTotalBalance);
		assertEquals(1200.0, targetTotalBalance);
		
	}
	
	@Test //test transazione cancellata per non aver confermato
	public void testExecuteAbortConf() {
		
		userAccountNumber=12345;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(2);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		assertEquals(200.0, targetTotalBalance);
		
	}
	
	@Test //test transazione terminata correttamente portando il conto alla massima capienza
	public void testExecuteOkMaxCash() {
		
		userAccountNumber=12345;
		int targetAccountNumber=56789;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(1);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(999.99, userAvailableBalance);
		assertEquals(1199.99, userTotalBalance);
		assertEquals(1000000.0, targetTotalBalance);
		
	}
	
	@Test //test transazione terminata correttamente col massimo dei soldi trasferibili
	public void testExecuteOkMaxTrans() {
		
		userAccountNumber=56789;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000000);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(0.0, userAvailableBalance);
		assertEquals(899999.99, userTotalBalance);
		assertEquals(100200.0, targetTotalBalance);
		
	}
	
	@Test //test transazione terminata per aver superato la capacita' massima del conto
	public void testExecuteKoMaxCash() {
		
		userAccountNumber=12345;
		int targetAccountNumber=56789;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(2);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(1000.0, userAvailableBalance);
		assertEquals(1200.0, userTotalBalance);
		assertEquals(999999.99, targetTotalBalance);
		
	}
	
	@Test  //test transazione terminata per aver superato il massimo disponibile sul conto
	public void testExecuteKoMaxTrans() {
		
		userAccountNumber=56789;
		int targetAccountNumber=98765;
		expect(atmKeypad.getInput(eq(5),anyBoolean())).andReturn(targetAccountNumber);
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000001);
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		executor.Transfert transfert=new executor.Transfert(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad);
		transfert.execute();
		
		
		double userAvailableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double userTotalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);

		double targetTotalBalance=atmBankDatabase.getTotalBalance(targetAccountNumber);
		assertEquals(100000.0, userAvailableBalance);
		assertEquals(999999.99, userTotalBalance);
		assertEquals(200.0, targetTotalBalance);
		
	}
	
}