package testJUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import store.Account;
import junit.framework.*;

public class BankDatabase extends TestCase {
	
	private Account accounts[]; // array of Accounts
	
	@Before
	public void setUp() throws Exception {
		accounts = new Account[ 4 ];
		accounts[ 0 ] = new Account( 12345, 54321, 1000.0, 1200.0 );
		accounts[ 1 ] = new Account( 98765, 56789, 200.0, 200.0 ); 
		accounts[ 2 ] = new Account( 56789, 98765, 99.99, 99.99 ); 
		accounts[ 3 ] = new Account( 54321, 12345, 100.01, 100.01 ); 
	}

	@After
	public void tearDown() throws Exception {

	}
	
	@Test //test funzionamento corretto
	public void testAutenticateUserOkNormal() {
		store.BankDatabase atmBankDatabase=new store.BankDatabase(accounts);
		boolean aux= atmBankDatabase.authenticateUser(12345, 54321);
		assertTrue(aux);
	}
	
	@Test //test utente errato
	public void testAutenticateUserKoUser() {
		store.BankDatabase atmBankDatabase=new store.BankDatabase(accounts);
		boolean aux= atmBankDatabase.authenticateUser(12346, 54321);
		assertFalse(aux);
	}
	
	@Test //test password errata
	public void testAutenticateUserKoPass() {
		store.BankDatabase atmBankDatabase=new store.BankDatabase(accounts);
		boolean aux= atmBankDatabase.authenticateUser(12345, 54322);
		assertFalse(aux);
	}
	
	@Test //test entrambi i dati errati
	public void testAutenticateUserKoBoth() {
		store.BankDatabase atmBankDatabase=new store.BankDatabase(accounts);
		boolean aux= atmBankDatabase.authenticateUser(12346, 54322);
		assertFalse(aux);
	}
}
