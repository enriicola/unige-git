package testJUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import visualization.CashDispenserVis;

import junit.framework.*;
import static org.easymock.classextension.EasyMock.*;
import static org.easymock.EasyMock.*;


public class CashDispenser extends TestCase {

	private CashDispenserVis guiCashDispenser;
	
	@Before
	public void setUp() throws Exception {
		guiCashDispenser=createMock(CashDispenserVis.class);
	}

	@After
	public void tearDown() throws Exception {
		
	}
	
	@Test //test se scala correttamente il numero di banconote
	public void testDispenseCashOkNormal() {
		guiCashDispenser.openDispenser();
		expect(guiCashDispenser.waitAction()).andReturn(true);
		replay(guiCashDispenser);
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		atmCashDispenser.dispenseCash(20);
	
		assertEquals(499,atmCashDispenser.getCount() );
		verify(guiCashDispenser);
	}
	
	@Test //test comportamento corretto al limite (prelevo tutte le banconote)
	public void testDispenseCashOkMax() {
		guiCashDispenser.openDispenser();
		expect(guiCashDispenser.waitAction()).andReturn(true);
		replay(guiCashDispenser);
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		atmCashDispenser.dispenseCash(10000);
	
		assertEquals(0,atmCashDispenser.getCount() );
		verify(guiCashDispenser);
	}
	
	@Test //test comportamento corretto
	public void testSufficientCashAvOkNormal() {
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		boolean aux=atmCashDispenser.isSufficientCashAvailable(20);
	
		assertTrue(aux );
		
	}
	
	@Test  //test comportamento corretto al limite delle banconote disponibili
	public void testSufficientCashAvOkMax() {
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		boolean aux=atmCashDispenser.isSufficientCashAvailable(10000);
	
		assertTrue(aux );
		
	}
	
	@Test  //test comportamento corretto appena oltre il limite delle banconote disponibili
	public void testSufficientCashAvKoBorder() {
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		boolean aux=atmCashDispenser.isSufficientCashAvailable(10020);
	
		assertFalse(aux );
		
	}
	
	@Test //test comportamento corretto prelevando piu banconote di quelle disponibili
	public void testSufficientCashAvKo() {
		
		boundary.CashDispenser atmCashDispenser=new boundary.CashDispenser(guiCashDispenser);
		boolean aux=atmCashDispenser.isSufficientCashAvailable(20000);
	
		assertFalse(aux );
		
	}
}
