package testJUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import store.Account;
import store.BankDatabase;
import visualization.KeyPadVis;
import visualization.ScreenVis;

import boundary.CashDispenser;
import boundary.Keypad;
import boundary.Screen;
import junit.framework.*;
import static org.easymock.classextension.EasyMock.*;
import static org.easymock.EasyMock.*;



public class Withdrawal extends TestCase {
	
	private int userAccountNumber; 
	private Screen atmScreen;
	private BankDatabase atmBankDatabase; 
	private Keypad atmKeypad; 
	private CashDispenser atmCashDispenser; 
	
	private double arrotonda(double numero, int nCifreDecimali) {
        return Math.round(numero * Math.pow(10, nCifreDecimali)) / Math.pow(10, nCifreDecimali);
    }
	
	@Before
	public void setUp() throws Exception {
		Account accounts[] = new Account[ 4 ];
		accounts[ 0 ] = new Account( 12345, 54321, 1000.0, 1200.0 );
		accounts[ 1 ] = new Account( 98765, 56789, 200.0, 200.0 ); 
		accounts[ 2 ] = new Account( 56789, 98765, 99.99, 99.99 ); 
		accounts[ 3 ] = new Account( 54321, 12345, 100.01, 100.01 ); 
		atmBankDatabase=new BankDatabase(accounts);
		atmScreen=new Screen(new ScreenVis());
		atmKeypad=createMock(Keypad.class);
		expect(atmKeypad.getVis()).andReturn(new KeyPadVis());
		atmCashDispenser=createMock(CashDispenser.class);
		expect(atmCashDispenser.dispenseCash(anyInt())).andReturn(true).times(0, 1); 
	}

	@After
	public void tearDown() throws Exception {
		verify(atmKeypad);
		verify(atmCashDispenser);
	}
	

	@Test  //test transazione terminata correttamente
	public void testExecuteOkNormal() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(true);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(980.0, availableBalance);
		assertEquals(1180.0, totalBalance);
		
	}
	
	@Test  //test transazione terminata correttamente prelevando al limite del saldo disponibile
	public void testExecuteOkBorderline() {
		
		userAccountNumber=54321;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(4);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(true);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(0.01, arrotonda(availableBalance,2));
		assertEquals(0.01, arrotonda(totalBalance,2));
	}
	
	@Test  //test transazione terminata correttamente prelevando tutti i soldi disponibili sul conto
	public void testExecuteOkEquals() {
		
		userAccountNumber=98765;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(5);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(true);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(0.0, availableBalance);
		assertEquals(0.0, totalBalance);
		
	}
	
	@Test  //test transazione cancellata per aver prelevato appena oltre al saldo disponibile
	public void testExecuteKoBorderline() {
		
		userAccountNumber=56789;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(4);
		replay(atmKeypad);
		
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(99.99, availableBalance);
		assertEquals(99.99, totalBalance);
		
	}
	
	@Test  //test transazione cancellata per aver prelevato oltre al saldo disponibile
	public void testExecuteKoNormal() {
		
		userAccountNumber=54321;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(5);
		replay(atmKeypad);
		
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(100.01, availableBalance);
		assertEquals(100.01, totalBalance);
		
	}
	
	@Test //test transazione cancellata per mancanza di banconote nell'atm
	public void testExecuteOkNormalNoCashAv() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(1);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(false);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(1000.0, availableBalance);
		assertEquals(1200.0, totalBalance);
		
	}
	
	@Test  //test transazione con prelievo al limite cancellata per mancanza di banconote nell'atm
	public void testExecuteOkBorderlineNoCashAv() {
		
		userAccountNumber=54321;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(4);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(false);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(100.01, availableBalance);
		assertEquals(100.01, totalBalance);
		
	}
	
	@Test 	//test transazione con prelievo di tutti i soldi disponibili 
			//cancellata per mancanza di banconote nell'atm
	public void testExecuteOkEqualsNoCashAv() {
		
		userAccountNumber=98765;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(5);
		replay(atmKeypad);
		
		expect(atmCashDispenser.isSufficientCashAvailable(anyInt())).andReturn(false);
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(200.0, availableBalance);
		assertEquals(200.0, totalBalance);
		
	}
	
	@Test //test transazione cancellata
	public void testExecuteAbort() {
		
		userAccountNumber=98765;
		
		expect(atmKeypad.getInput(eq(1),anyBoolean())).andReturn(6);
		replay(atmKeypad);
		
		replay(atmCashDispenser);
		
		executor.Withdrawal withdrawal=new executor.Withdrawal(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmCashDispenser);
		withdrawal.execute();
		
		
		double availableBalance=atmBankDatabase.getAvailableBalance(userAccountNumber);
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		assertEquals(200.0, availableBalance);
		assertEquals(200.0, totalBalance);
		
	}
	
}
