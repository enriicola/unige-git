package testJUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import store.Account;
import store.BankDatabase;
import visualization.ScreenVis;

import boundary.DepositSlot;
import boundary.Keypad;
import boundary.Screen;
import junit.framework.*;
import static org.easymock.classextension.EasyMock.*;
import static org.easymock.EasyMock.*;



public class Deposit extends TestCase {
	
	private int userAccountNumber; 
	private Screen atmScreen;
	private BankDatabase atmBankDatabase; 
	private Keypad atmKeypad; 
	private DepositSlot atmDepositSlot; 
	
	@Before
	public void setUp() throws Exception {
		Account accounts[] = new Account[ 3 ];
		accounts[ 0 ] = new Account( 12345, 54321, 1000.0, 1200.0 );
		accounts[ 1 ] = new Account( 98765, 56789, 200.0, 200.0 ); 
		accounts[ 2 ] = new Account( 56789, 98765, 99.99, 999999.99 ); 
		atmBankDatabase=new BankDatabase(accounts);
		atmScreen=new Screen(new ScreenVis());
		atmKeypad=createMock(Keypad.class);
		atmDepositSlot=createMock(DepositSlot.class);
	}

	@After
	public void tearDown() throws Exception {
		verify(atmKeypad);
		verify(atmDepositSlot);
	}
	

	@Test //test transazione terminata correttamente
	public void testExecuteOkNormal() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000); 
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1300.0, totalBalance);
		
	}
	
	@Test //test transazione terminata correttamente depositando zero dollari
	public void testExecuteOkZero() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(0); 
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1200.0, totalBalance);
		
	}
	
	@Test //test transazione terminata correttamente depositando il minimo
	public void testExecuteOkMin() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(1); 
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1200.01, totalBalance);
		
	}
	
	@Test //test transazione cancellata
	public void testExecuteAbort() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(-2);
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1200.0, totalBalance);
		
	}

	@Test //test transazione terminata per non aver immesso i soldi nello sportello
	public void testExecuteOkNormalNoEnvelopeRec() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000);
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(false).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1200.0, totalBalance);
		
	}
	
	@Test//test transazione terminata correttamente depositando il massimo
	public void testExecuteOkDepositMax() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(10000000); 
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(101200.0, totalBalance);
		
	}
	
	@Test //test transazione terminata correttamente portando il conto alla massima capienza
	public void testExecuteOkContoMax() {
		
		userAccountNumber=56789;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(1); 
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1000000.00, totalBalance);
		
	}
	
	@Test //test transazione cancellata per aver depositato oltre il limite consentito
	public void testExecuteKoOverflowDeposit() {
		
		userAccountNumber=12345;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(100000001);
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(1200.0, totalBalance);
		
	}
	
	@Test //test transazione cancellata per aver depositato oltre la capacita disponibile sul conto
	public void testExecuteKoOverflowConto() {
		
		userAccountNumber=56789;
		
		expect(atmKeypad.getInput(eq(7),anyBoolean())).andReturn(2);
		replay(atmKeypad);
		
		expect(atmDepositSlot.isEnvelopeReceived()).andReturn(true).times(0, 1);
		replay(atmDepositSlot);
		
		executor.Deposit deposit=new executor.Deposit(userAccountNumber,atmScreen,atmBankDatabase,atmKeypad,atmDepositSlot);
		deposit.execute();
		
		
		double totalBalance=atmBankDatabase.getTotalBalance(userAccountNumber);
		
		assertEquals(999999.99, totalBalance);
		
	}
	
}
