package executor;

import store.BankDatabase;

import visualization.KeyPadVis;

import boundary.DepositSlot;
import boundary.Keypad;
import boundary.Screen;

// Deposit.java
// Represents a deposit ATM transaction

public class Deposit extends Transaction {
	private double amount; // amount to deposit
	private DepositSlot depositSlot; // reference to deposit slot
	
	// Deposit constructor
	public Deposit(int userAccountNumber, Screen atmScreen,
			BankDatabase atmBankDatabase, Keypad atmKeypad,
			DepositSlot atmDepositSlot) {
		// initialize superclass variables
		super(userAccountNumber, atmScreen, atmBankDatabase, atmKeypad);

		// initialize references to deposit slot
		depositSlot = atmDepositSlot;
	} // end Deposit constructor

	// perform transaction
	public void execute() {
		BankDatabase bankDatabase = getBankDatabase(); // get reference
		Screen screen = getScreen(); // get reference
		amount = promptForDepositAmount(); // get deposit amount from user

		// check whether user entered a deposit amount or canceled
		if (amount != KeyPadVis.CANC) {
			//controlla che l'importo non sia superiore alla soglia stabilita
			if (amount > 1000000) {
				screen.displayMessage("Il deposito massimo e' 100.000$");
				screen.displayMessage("Cancellazione transazione...");
				return;
			}
			//controlla che il bilancio non sfori il tetto massimo stabilita
			if (bankDatabase.getTotalBalance(getAccountNumber()) + amount > 1000000) {
				screen.displayMessage("Il conto puo' avere massimo 1.000.000$");
				screen.displayMessage("Cancellazione transazione...");
				return;
			}

			// request deposit envelope containing specified amount
			screen.displayMessage("Perfavore inserisci una busta\ncon i soldi da depositare");

			// receive deposit envelope
			boolean envelopeReceived = depositSlot.isEnvelopeReceived();

			// check whether deposit envelope was received
			if (envelopeReceived) {
				screen.displayMessage("Il tuo deposito e' stato ricevuto");
				// credit account to reflect the deposit
				bankDatabase.credit(getAccountNumber(), amount);
				screen.displayMessage("Transazione eseguita");
			} // end if
			else // deposit envelope not received
			{
				screen.displayMessage("Non hai inserito nessuna busta");
				screen.displayMessage("Cancellazione transazione...");
			} // end else
		} // end if
		else // user canceled instead of entering amount
		{
			screen.displayMessage("Cancellazione transazione...");
		} // end else
	} // end method execute

	// prompt user to enter a deposit amount in cents
	private double promptForDepositAmount() {
		Screen screen = getScreen(); // get reference to screen
		Keypad keypad = getKeypad();
		// display the prompt
		screen.displayMessage("Perfavore inserisci la somma del deposito",
				"in cent (o Canc per tornare indietro)");
		int input = keypad.getInput(7, true); // receive input of deposit amount

		// check whether the user canceled or entered a valid amount
		if (input == KeyPadVis.CANC)
			return KeyPadVis.CANC;

		return (double) input / 100; // return dollar amount
		// end else
	} // end method promptForDepositAmount
} // end class Deposit

/**************************************************************************
 * (C) Copyright 1992-2007 by Deitel & Associates, Inc. and * Pearson Education,
 * Inc. All Rights Reserved. * * DISCLAIMER: The authors and publisher of this
 * book have used their * best efforts in preparing the book. These efforts
 * include the * development, research, and testing of the theories and programs
 * * to determine their effectiveness. The authors and publisher make * no
 * warranty of any kind, expressed or implied, with regard to these * programs
 * or to the documentation contained in these books. The authors * and publisher
 * shall not be liable in any event for incidental or * consequential damages in
 * connection with, or arising out of, the * furnishing, performance, or use of
 * these programs. *
 *************************************************************************/
