package executor;

import store.BankDatabase;

import visualization.KeyPadVis;

import boundary.Keypad;
import boundary.Screen;

public class Transfert extends Transaction {

	public Transfert(int userAccountNumber, Screen atmScreen,
			BankDatabase atmBankDatabase, Keypad atmKeypad) {
		super(userAccountNumber, atmScreen, atmBankDatabase, atmKeypad);
	}

	// perform transaction
	public void execute() {
		// get references to bank database, keypad and screen
		BankDatabase bankDatabase = getBankDatabase();
		Screen screen = getScreen();
		Keypad keypad = getKeypad();

		// richiede numero conto su cui trasferire i soldi
		screen.displayMessage("Inserisci N� di conto del destinatario",
				"(o Canc per tornare indietro)");
		int targetAccountNumber = keypad.getInput(5, true);

		// controlla se l'utente ha scelto di interrompere la transazione
		if (targetAccountNumber == KeyPadVis.CANC) {
			screen.displayMessage("Cancellazione transazione...");
			return;
		}
		// controlla che il destinatario non sia l'utente stesso
		if (targetAccountNumber == getAccountNumber()) {
			screen.displayMessage("Non puoi trasferirti soldi da solo");
			screen.displayMessage("Cancellazione transazione...");
			return;
		}
		// controlla che il destinatario esista
		if (!bankDatabase.existUser(targetAccountNumber)) {
			screen.displayMessage("Numero di conto inesistente");
			screen.displayMessage("Cancellazione transazione...");
			return;
		}
		// display the prompt
		screen.displayMessage("Perfavore inserisci la somma del deposito",
				"in cent (o Canc per tornare indietro)");
		int input = keypad.getInput(7, true); // receive input of deposit amount

		// check whether the user canceled or entered a valid amount
		if (input == KeyPadVis.CANC) {
			screen.displayMessage("Cancellazione transazione...");
			return;
		}
		// convert to dollar amount
		double amount = (double) input / 100;

		// richiede conferma del trasferimento
		screen.displayMessage("Confermi il trasferimento", targetAccountNumber,
				amount, keypad);
		int choice;
		while ((choice = keypad.getInput(1, false)) != 2 && choice != 1) {
		}
		if (choice == 2) {
			screen.displayMessage("Cancellazione transazione...");
			return;
		}

		// controlla che l'importo non sia superiore alla soglia stabilita
		if (amount > 100000) {
			screen.displayMessage("Il trasferimento massimo e' 100.000$");
			screen.displayMessage("Cancellazione transazione...");
			return;
		}

		// controlla che il bilancio non sfori il tetto massimo stabilita
		if (bankDatabase.getTotalBalance(targetAccountNumber) + amount > 1000000) {
			screen.displayMessage("Il conto puo' avere massimo 1.000.000$");
			screen.displayMessage("Cancellazione transazione...");
			return;
		}

		// get available balance of account involved
		double availableBalance = bankDatabase
				.getAvailableBalance(getAccountNumber());

		// check whether the user has enough money in the account

		if (amount > availableBalance){ // not enough money available in user's account
			screen.displayMessage("Non hai abbastanza soldi sul tuo conto."
					+ "\nPerfavore scegli un importo minore.");
			screen.displayMessage("Cancellazione transazione...");
			return;
		}

		bankDatabase.debit(getAccountNumber(), amount);
		bankDatabase.credit(targetAccountNumber, amount);
		screen.displayMessage("Transazione eseguita");

	}// end method execute

}// end class Transfert
