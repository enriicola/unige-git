package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;

@SuppressWarnings("serial")
//Bottoni dello schermo TouchScreen
public class ScreenButton extends JButton {

    private int num;
    private boolean left;
    private int width = 300, height = 50;
    
    public int getChoiseNum(){
    	return num;
    }
    
    public ScreenButton(String s, int n) {
        super(s);
        num = n;
        left = n % 2 != 0; //dispari
        setLayout(null);
        setForeground(new Color(225, 225, 225));
        setFont(Font.decode("Arial-PLAIN-38"));
        setMaximumSize(new Dimension(width, height));
        setPreferredSize(new Dimension(width, height));
        if (left) {
            setBorder(BorderFactory.createEmptyBorder(0, height, 0, 0));
            setHorizontalAlignment(SwingConstants.LEFT);
        } else {
            setBorder(BorderFactory.createEmptyBorder(0, 0, 0, height));
            setHorizontalAlignment(SwingConstants.RIGHT);
        }
        setUI(new BasicButtonUI() {

            @Override
            public void paint(Graphics g, JComponent c) {
                c.setBackground(new Color(0, 110, 180));
                super.paint(g, c);
                if (left) {
                    add(new Num(num, left)).setBounds(0, 5, 40, 40);
                } else {
                    add(new Num(num, left)).setBounds(getWidth() - 40, 5, 40, 40);
                }
            }

            @Override
            public void paintButtonPressed(Graphics g, AbstractButton b) {
                b.setBackground(new Color(45, 155, 230));
            }
        });

    }
}

@SuppressWarnings("serial")
//Pannello per mostrare il numero all'interno del bottone
class Num extends JPanel {

    boolean left;
    int num;

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        Color g1 = new Color(145, 85, 80);
        Color g2 = new Color(245, 50, 20);
        GradientPaint gradient1;
        if (left) {
            gradient1 = new GradientPaint(00, 00, g1, 40, 40, g2, true);
        } else {
            gradient1 = new GradientPaint(60, 00, g1, 00, 40, g2, true);
        }
        g2d.setPaint(gradient1);
        g2d.fillRect(0, 0, 40, 40);
        g.setColor(Color.lightGray);
        g.setFont(Font.decode("Arial-PLAIN-28"));
        g.drawString(num + "", 15, 30);
    }

    public Num(int i, boolean left) {
        this.left = left;
        num = i;
    }
}
