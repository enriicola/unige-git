package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import visualization.KeyPadVis;



@SuppressWarnings("serial")
//pannello per mostrare i menu
public class ScreenOption extends JPanel implements ActionListener {

	private int nChoice = 0;
	private GridBagConstraints gbc = new GridBagConstraints();
	private JPanel space = new JPanel();
	private KeyPadVis kp;

	final public void addChoice(String s) {
		int y, x;
		y = nChoice / 2;
		nChoice++;
		if (nChoice % 2 != 0) {
			x = 0;
		} else {
			x = 2;
		}
		ScreenButton sb = new ScreenButton(s, nChoice);
		sb.addActionListener(this);
		add(sb, x, y);
	}

	private void add(Component c, int x, int y) {
		gbc.gridx = x;
		gbc.gridy = y;
		add(c, gbc);
	}

	public ScreenOption(KeyPadVis kp) {
		this.kp = kp;
		setLayout(new GridBagLayout());

		Insets in = new Insets(10, 0, 10, 0);
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.insets = in;
		gbc.weightx = 1000;
		// pannello per inserire lo spazio tra le due colonne del menu
		space.setPreferredSize(new Dimension(800 - 600 - 20, 0));
		add(space, 1, 0);

	}

	@Override
	public int getHeight() {
		return getLayout().preferredLayoutSize(this).height;
	}

	public void actionPerformed(ActionEvent e) {
		kp.virtualPress(((ScreenButton) e.getSource()).getChoiseNum());

	}
}
