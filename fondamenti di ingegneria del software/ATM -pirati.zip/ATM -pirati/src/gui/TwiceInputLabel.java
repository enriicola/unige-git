package gui;

import java.awt.GridLayout;

import javax.swing.*;


@SuppressWarnings("serial")
//pannello con doppia etichetta per visualizzare in tempo reale l'input
public class TwiceInputLabel extends JPanel implements UserInput {

	private JLabel ul1;
	private JLabel ul2;
	private JLabel ul3 = new JLabel("");
	private JPanel pan = new JPanel();
	private int digit = 0;
	private String numbers = "";

	public TwiceInputLabel(String message,String message2) {
		pan.setLayout(new GridLayout(3, 1, 0,0));
		ul1 = new JLabel(message);
		ul2 = new JLabel(message2);
		ul1.setFont(NORMAL);
		ul2.setFont(NORMAL);
		ul3.setFont(BIG);
		pan.add(ul1);
		pan.add(ul2);
		pan.add(ul3);
		add(pan);
		setSize(700, 200);
		setPreferredSize(getSize());
	}

	public String getDigitText() {
		return digit + "";
	}

	public void addNumber(int n) {
		numbers += " " + n;
		digit = digit * 10 + n;
		ul3.setText(numbers);
	}

	public void delNumber() {
		if (digit <= 0)
			numbers = "";
		else
			numbers = numbers.substring(0, numbers.length() - 2);
		digit /= 10;
		ul3.setText(numbers);
	}

}
