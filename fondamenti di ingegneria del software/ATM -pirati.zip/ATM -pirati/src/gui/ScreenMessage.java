package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.*;


@SuppressWarnings("serial")
//pannelli per i messaggi
public class ScreenMessage extends JPanel {

	private String[] msg;
	private JPanel pan = new JPanel();

	@Override
	public void paint(Graphics g) {
		int roundSize = 40;
		g.setColor(new Color(0, 110, 180));
		g.fillRoundRect(0, 0, getWidth() - 10, getHeight() - 10, roundSize,
				roundSize);
		super.paint(g);
	}

	public ScreenMessage(String msg) {
		this.msg = msg.split("\n");
		setLayout(new BorderLayout());
		pan.setLayout(new GridLayout(this.msg.length, 1));
		for (String s : this.msg) {
			if (s.isEmpty())
				continue;
			JLabel l = new JLabel(s);
			l = new JLabel(s);
			l.setFont(InputLabel.NORMAL);
			l.setForeground(Color.white);
			l.setHorizontalAlignment(SwingConstants.CENTER);
			pan.add(l);
		}

		add(pan, BorderLayout.CENTER);
		setBackground(new Color(0, 0, 0, 0));
		pan.setBackground(new Color(0, 0, 0, 0));
		setSize(500, 200);
		setPreferredSize(new Dimension(500, 200));
	}
}
