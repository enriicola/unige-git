package gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import visualization.KeyPadVis;

@SuppressWarnings("serial")
// schermata di conferma
public class ConfirmPanel extends JPanel {
	
	public ConfirmPanel(String message,KeyPadVis keypad, int account, double amount) {
		setLayout(new BorderLayout());
		JLabel t = new JLabel(message);
		JLabel c = new JLabel("al conto "+account+" di "+amount+" dollari?");
		JPanel text = new JPanel(new GridLayout(2,1));
		t.setFont(UserInput.NORMAL);
		t.setHorizontalAlignment(SwingConstants.CENTER);
		c.setFont(UserInput.NORMAL);
		c.setHorizontalAlignment(SwingConstants.CENTER);
		
		text.add(t);
		text.add(c);
		
		add(text, BorderLayout.NORTH);
		ScreenOption so = new ScreenOption(keypad);
		so.addChoice("Si");
		so.addChoice("No");
		add(so, BorderLayout.SOUTH);
		setSize(780, 210);
		setPreferredSize(getSize());
	}

}
