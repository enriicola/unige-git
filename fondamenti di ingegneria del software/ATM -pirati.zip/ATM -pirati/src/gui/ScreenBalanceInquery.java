package gui;

import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
//tabella di visualizzazione del bilancio
public class ScreenBalanceInquery extends JPanel {

    JTable tab;
    String[] colName = {"Saldo Contabile", "Saldo Disponibile"};
    Object[][] data = {{"", ""}};
    Dimension d;
    JLabel lab = new JLabel("Premere qualunque tasto per uscire");

    public ScreenBalanceInquery(double cont, double disp) {
        setLayout(new BorderLayout());
        data[0][0] = cont;
        data[0][1] = disp;
        lab.setFont(InputLabel.NORMAL);
        
        tab = new JTable(data, colName);
        tab.getTableHeader().setBackground(new Color(0, 110, 180));
        tab.getTableHeader().setForeground(Color.WHITE);
        tab.getTableHeader().setFont(Font.decode("Arial-PLAIN-22"));
        tab.setRowHeight(30);
        tab.setFont(Font.decode("Arial-PLAIN-20"));
        
        add(tab.getTableHeader(), BorderLayout.PAGE_START);
        add(tab, BorderLayout.CENTER);
        add(lab, BorderLayout.PAGE_END);
        
        d = new Dimension(600, getLayout().preferredLayoutSize(this).height);
        setSize(d);
        setPreferredSize(d);
    }
}
