package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

@SuppressWarnings("serial")
//Bottoni Personalizzati per il keypad
public class KeyPadButton extends JButton {

    final Border b = BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 0, 1, 1),
            new RoundedBorder(Color.darkGray, 20));
    final Border bPr = BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 0, 1, 1),
            new RoundedBorder(Color.black, 20));
    ModifButtonUI mUI = new ModifButtonUI();

    public KeyPadButton(int i) {
        this(i + "");
    }

    public KeyPadButton(String s) {

        if (s.length() == 1) {
            setFont(Font.decode("Arial-PLAIN-46"));
        } else {
            if (s.charAt(0) == ('e' & 'E')) {
                setForeground(new Color(44, 155, 35));
            } else if (s.charAt(0) == ('c' & 'C')) {
                setForeground(Color.RED);
            }
            setFont(Font.decode("Arial-PLAIN-20"));
        }
        setBackground(new Color(167, 167, 167));
        setText(s);
        mUI.setBackgroundColor(new Color(192, 192, 192));
        setUI(mUI);
        getModel().addChangeListener(new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e) {
                ButtonModel model = (ButtonModel) e.getSource();
                if (model.isRollover()) {
                    mUI.setBackgroundColor(new Color(210, 210, 210));
                    setBorder(b);
                } else {
                    mUI.setBackgroundColor(new Color(192, 192, 192));
                    setBorder(b);
                }
                if (model.isPressed()) {
                    setBorder(bPr);
                }
            }
        });
        setActionCommand(s);
        setBorder(b);
        setMinimumSize(new Dimension(90, 60));
        setPreferredSize(new Dimension(90, 60));
    }
}