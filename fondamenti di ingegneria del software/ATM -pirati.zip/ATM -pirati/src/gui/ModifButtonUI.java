package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.metal.MetalButtonUI;

class ModifButtonUI extends MetalButtonUI {

    public static ComponentUI createUI(JComponent c) {
        return new ModifButtonUI();
    }
    private Color col;
    
    public void setBackgroundColor(Color c) {
        col = c;
    }

    @Override
    public void paint(Graphics g, JComponent c) {
        int roundSize =20;
        g.setColor(col);
        g.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), roundSize, roundSize);
        super.paint(g, c);
    }

    @Override
    public void paintButtonPressed(Graphics g, AbstractButton b) {
        paintText(g, b, b.getBounds(), b.getText());
        int roundSize = 20;
        g.setColor(new Color(190, 190, 190));
        g.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), roundSize, roundSize);
    }

    @Override
    protected void paintFocus(Graphics g, AbstractButton b,
            Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
    }
}