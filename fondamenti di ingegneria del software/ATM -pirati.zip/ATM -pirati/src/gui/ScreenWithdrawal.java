package gui;

import visualization.KeyPadVis;


@SuppressWarnings("serial")
//pannello per il menu del prelievo
public class ScreenWithdrawal extends ScreenOption{

	public ScreenWithdrawal(KeyPadVis kp) {
		super(kp);
		addChoice("20");
		addChoice("40");
		addChoice("60");
		addChoice("100");
		addChoice("200");
		addChoice("Indietro");
	}

}
