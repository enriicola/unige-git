package gui;

import java.awt.*;
//interfaccia per le etichette che visualizzano l'input in tempo reale
public interface UserInput {

	public final static Font BIG = Font.decode("Arial-PLAIN-35");
	public final static Font NORMAL = Font.decode("Arial-PLAIN-28");
	public final static Font SMALL = Font.decode("Arial-PLAIN-20");

	public String getDigitText();

	public void addNumber(int n);

	public void delNumber();
}
