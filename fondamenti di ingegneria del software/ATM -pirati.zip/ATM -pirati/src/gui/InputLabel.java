package gui;

import javax.swing.*;

@SuppressWarnings("serial")
//etichetta per visualizzare in tempo reale l'input
public class InputLabel extends JLabel implements UserInput{

	private String text = "";
	private String lines = " _ _ _ _ _";
	private String numbers = "";
	private int digit = 0;
	private boolean psw;
	private int in = 0;

	public InputLabel(String text, boolean psw) {
		this.text = text;
		this.psw = psw;
		setFont(BIG);
		setText(text + " " + lines);
		setSize(500, 150);
	}

	public void addNumber(int n) {
		if (in > 5) {
			return;
		}
		if (in < 4) {
			lines = lines.substring(2);
		}else{
			lines = "";
		}
		
		if (psw) { //occulta la digitazione del pin
			numbers += " *";
		} else {
			numbers += " "+ n;
		}
		digit = digit * 10 + n;
		setText(text  + numbers + lines);
		in++;
	}

	public void delNumber() {
		if (in <= 0) {
			return;
		}
		in--;
		lines += " _";
		numbers = numbers.substring(0, numbers.length()-2);
		digit /= 10;
		setText(text + " " + numbers + lines);
	}


	public String getDigitText() {
		return digit+"";
	}
	
	@Override
	public int getHeight() {
		return 150;
	}
}
