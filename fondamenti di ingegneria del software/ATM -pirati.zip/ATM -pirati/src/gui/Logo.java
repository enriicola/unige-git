package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.*;

@SuppressWarnings("serial")
//Pannello con Logo
public class Logo extends JPanel {

    BufferedImage img;

    public Logo() {
        super(false); //crea un JPanel con doubleBuffered true
        try {
            img = ImageIO.read(getClass().getResource("/img/GNB.gif"));
        } catch (Exception e) {
        }
        setBackground(new Color(0, 0, 0, 0));
        setPreferredSize(new Dimension(img.getWidth(), img.getHeight()));
    }

    @Override
    public int getHeight() {
        return img.getHeight();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(img, 0, 0, null);
    }
}
