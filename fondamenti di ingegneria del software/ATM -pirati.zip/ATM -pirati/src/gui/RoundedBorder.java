package gui;

import java.awt.*;
import javax.swing.border.*;

class RoundedBorder extends AbstractBorder {

    private static int MARGIN = 5;
    private static final long serialVersionUID = 1L;
    private Color color;

    public RoundedBorder(Color clr) {
        color = clr;
    }

    public RoundedBorder(Color clr, int arcSize) {
        color = clr;
        MARGIN = arcSize;
    }

    public void setColor(Color clr) {
        color = clr;
    }

    public void setArcSize(int arcSize) {
        MARGIN = arcSize;
    }

    public int getArcSize() {
        return MARGIN;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        ((Graphics2D) g).setRenderingHint(
                RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(color);
        g.drawRoundRect(x, y, width, height, MARGIN, MARGIN);
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(MARGIN, MARGIN, MARGIN, MARGIN);
    }

    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.left = MARGIN;
        insets.top = MARGIN;
        insets.right = MARGIN;
        insets.bottom = MARGIN;
        return insets;
    }
}