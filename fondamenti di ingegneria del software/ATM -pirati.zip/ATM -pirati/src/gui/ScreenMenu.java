package gui;

import visualization.KeyPadVis;


@SuppressWarnings("serial")
//pannello per il main manu di scelta
public class ScreenMenu extends ScreenOption {

	public ScreenMenu(KeyPadVis kp) {
		super(kp);
		addChoice("Saldo");
        addChoice("Prelievo");
        addChoice("Deposito");
        addChoice("Trasferimento");
        addChoice("Esci");

	}

	
}
