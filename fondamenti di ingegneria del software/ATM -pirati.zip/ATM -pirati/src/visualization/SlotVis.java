package visualization;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.*;

@SuppressWarnings("serial")
//superclasse per gestire gli sportelli
public class SlotVis extends JPanel {

	private URL close;
	private URL open;
	private JLabel l;
	private boolean opened;
	private boolean clicked;
	private Dispenser d;

	public SlotVis(String text) {
		super(true);
		clicked = false;
		close = getClass().getResource("/img/closeDisp.jpg");
		open = getClass().getResource("/img/openDisp.jpg");
		setLayout(new BorderLayout(0, 20));
		l = new JLabel(text);
		l.setHorizontalAlignment(JLabel.CENTER);
		l.setFont(Font.decode("Arial-PLAIN-22"));
		d = new Dispenser(close);
		d.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent arg0) {
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				clicked = true;
			}
		});
		setBackground(new Color(140, 140, 140));
		add(d, BorderLayout.PAGE_START);
		add(l, BorderLayout.CENTER);
		setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));
		opened = false;
	}

	public void openDispenser() {
		opened = true;
		d.setImg(open);
		repaint();
	}

	public void closeDispenser() {
		opened = false;
		clicked = false;
		d.setImg(close);
		repaint();
	}

	public boolean waitAction() {
		int tempo = 0;
		while(!clicked && tempo < 150) {
			tempo++;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		closeDispenser();
		if(tempo==150)
			return false;
		return true;
	}

	public boolean isOpen() {
		return opened;
	}
}

@SuppressWarnings("serial")
//gestisce immagine sportello
class Dispenser extends JPanel {

	URL file;
	private BufferedImage img;

	public void setImg(URL f) {
		file = f;
		repaint();
	}

	public Dispenser(URL f) {
		setImg(f);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		try {
			img = ImageIO.read(file);
			setPreferredSize(new Dimension(img.getWidth(), img.getHeight()));
			setSize(new Dimension(img.getWidth(), img.getHeight()));
		} catch (Exception e) {
		}
		g.drawImage(img, 0, 0, null);
	}
}