package visualization;

import gui.Logo;
import gui.UserInput;

import java.awt.*;

import javax.swing.*;

@SuppressWarnings("serial")
//visualizzazione grafica dello schermo
public class ScreenVis extends JPanel {

    private Logo logo = new Logo();
    private JPanel pan = new JPanel(true);
    private final static int whidth = 800, height = 435;
    GridBagConstraints gbc = new GridBagConstraints();

    public ScreenVis() {
        ((FlowLayout) getLayout()).setVgap(20);
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 10));
        pan.setBackground(new Color(0, 0, 0, 0));
        add(logo);
        add(pan);
        setMinimumSize(new Dimension(whidth, height));
        setPreferredSize(new Dimension(whidth, height));
    }
    
    @Override
    public void paint(Graphics g) {

        Graphics2D g2d = (Graphics2D) g;
        Color g1 = new Color(235, 235, 235, 10);
        Color g2 = new Color(190, 220, 220, 60);
        GradientPaint gradient1 = new GradientPaint(00, 00, g2, 0, 500, g1,true);
        g2d.setPaint(gradient1);
        g2d.fillRect(0, 0, whidth, height);
        super.paint(g);
    }
    
    //imposta il pannello da visualizzare sullo schermo
    public void setPan(JComponent p) {
        pan.removeAll();
        pan.setPreferredSize(new Dimension(whidth - 20, p.getHeight()));
        pan.add(p);        
        revalidate();
        try {
            Thread.sleep(10);
        } catch (InterruptedException ex) {
        }
        repaint();
    }

    public void addDigit(int n) {
        try {
            UserInput aux = (UserInput) pan.getComponent(0);
            if (n >= 0) {
                aux.addNumber(n);
            } else {
                aux.delNumber();
            }
            repaint();
        } catch (ClassCastException e) {//se il cast fallisce non si deve fare nulla 
        }
    }
}
