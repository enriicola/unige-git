package visualization;

import java.awt.*;
import javax.swing.*;
//visualizzazione grafica dell'ATM
public class AtmVis {

	private JFrame f = new JFrame("ATM");
    private JPanel botton = new JPanel();
    private JPanel CD = new JPanel();
    private JPanel all = new JPanel();
    private JPanel all2 = new JPanel();
    
    private KeyPadVis keypad = new KeyPadVis();
    private ScreenVis schermo = new ScreenVis();
    private CashDispenserVis prelievo = new CashDispenserVis();
    private DepositSlotVis deposito = new DepositSlotVis();
    
   
	
	public AtmVis() {

    	all.setLayout(new BorderLayout());
        botton.setLayout(new BorderLayout(20, 10));
        CD.setLayout(new GridLayout(2,1));
       
        all2.setBackground(new Color(140, 140, 140));
        all.add(schermo, BorderLayout.NORTH);
        CD.add(prelievo);
        CD.add(deposito);
        botton.add(keypad,BorderLayout.WEST);
        botton.add(CD,BorderLayout.EAST);
        botton.setBackground(new Color(140, 140, 140));
        botton.setBorder(BorderFactory.createEmptyBorder(5, 20, 5, 20));
        all.add(botton);
        all2.add(all, BorderLayout.CENTER);
        f.getContentPane().add(all2);
        f.pack();
        f.setVisible(true);
        f.setDefaultCloseOperation(3);
    }
    public KeyPadVis getKeypad() {
		return keypad;
	}

	public ScreenVis getSchermo() {
		return schermo;
	}

	public CashDispenserVis getPrelievo() {
		return prelievo;
	}
	
	public DepositSlotVis getDeposito() {
		return deposito;
	}

	public void setKeypad(KeyPadVis keypad) {
		this.keypad = keypad;
	}

	public void setSchermo(ScreenVis schermo) {
		this.schermo = schermo;
	}

	public void setPrelievo(CashDispenserVis prelievo) {
		this.prelievo = prelievo;
	}
	
	public void setDeposito(DepositSlotVis deposito) {
		this.deposito = deposito;
	}
}
