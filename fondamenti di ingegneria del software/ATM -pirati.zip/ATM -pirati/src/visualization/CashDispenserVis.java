package visualization;

@SuppressWarnings("serial")
//visualizzazione grafica dello sportello per il prelievo
public class CashDispenserVis extends SlotVis {

	public CashDispenserVis() {
		super("Prelievo");
	}

}