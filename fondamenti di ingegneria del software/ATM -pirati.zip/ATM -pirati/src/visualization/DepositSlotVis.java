package visualization;

@SuppressWarnings("serial")
//visualizzazione grafica dello sportello per il deposito
public class DepositSlotVis extends SlotVis {

	public DepositSlotVis() {
		super("Deposito");
	}
	

}
