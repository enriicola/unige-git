package visualization;

import gui.KeyPadButton;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

@SuppressWarnings("serial")
//visualizzazione grafica della tastiera
public class KeyPadVis extends JPanel implements ActionListener {

    KeyPadButton[] buttons = new KeyPadButton[12];
    private int value;
    private boolean ok = false;
    public static int OK = -1;
    public static int CANC = -2;
    public KeyPadVis() {
        setLayout(new GridLayout(4, 3, 4, 4));
        for (int i = 0; i < 9; i++) {
            buttons[i] = new KeyPadButton(i + 1);
            buttons[i].addActionListener(this);
            add(buttons[i]);
        }
        buttons[9] = new KeyPadButton("Enter");
        buttons[9].addActionListener(this);
        buttons[10] = new KeyPadButton(0);
        buttons[10].addActionListener(this);
        buttons[11] = new KeyPadButton("Canc");
        buttons[11].addActionListener(this);
        add(buttons[9]);
        add(buttons[10]);
        add(buttons[11]);
        setBorder(BorderFactory.createLineBorder(new Color(167, 167, 167), 15));
        setBackground(new Color(167, 167, 167));
    }

    public int getInput() {
        value = 0;
        while (!ok) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
            }
        }
        ok = false;
        return value;
    }
    
    //Metodo per aggiornare il valore digitato senza schiacciare i tasti del keypad (simulando un TouchScreen)
    public void virtualPress(int n){
    	value = n;
        ok = true;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            value = Integer.parseInt(e.getActionCommand());
        } catch (NumberFormatException nex) {
            if (e.getActionCommand().equalsIgnoreCase("enter")) {
                value = OK;
            } else {
                value = CANC;
            }
        }
        ok = true;
    }
}