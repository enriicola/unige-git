package boundary;

import gui.ConfirmPanel;
import gui.InputLabel;
import gui.ScreenBalanceInquery;
import gui.TwiceInputLabel;
import gui.ScreenMenu;
import gui.ScreenMessage;
import gui.ScreenWithdrawal;

import visualization.ScreenVis;

// Screen.java
// Represents the screen of the ATM

public class Screen {
	private ScreenVis vis;

	public Screen(ScreenVis s) {
		vis = s;
	}

	// mostra un messaggio temporaneo
	public void displayMessage(String message) {
		vis.setPan(new ScreenMessage(message));
  	  try {
   	   Thread.sleep(2000);
   	  } catch (InterruptedException e) {
   	   e.printStackTrace();
   	  }
	} // end method displayMessage
	
	// mostra i menu di opzione
	public void displayMessage(String message,boolean opt,Keypad keypad) {
		if(opt) {
			vis.setPan(new ScreenMenu(keypad.getVis()));
			return;
		}
		displayMessage(message);
		vis.setPan(new ScreenWithdrawal(keypad.getVis()));
	} // end method displayMessage
	
	//mostra il menu di conferma
	public void displayMessage(String message,int account, double amount,Keypad keypad) {
		vis.setPan(new ConfirmPanel(message,keypad.getVis(),account,amount));
	}// end method displayMessage
	
	//mostra la schermata di inserimento
	public void displayMessage(String message,boolean opt) {
		vis.setPan(new InputLabel(message, opt));
	} // end method displayMessage
	
	//mostra la tabella del bilancio
	public void displayMessage(double totalBalance,double availableBalance) {
		vis.setPan(new ScreenBalanceInquery(totalBalance, availableBalance));
	} // end method displayMessage
	
	//mostra la schermata di inserimanto con 2 strighe
	public void displayMessage(String message,String message2) {
		vis.setPan(new TwiceInputLabel(message,message2));
	} // end method displayMessage

	public ScreenVis getVis() {
		return vis;
	}

	public void setVis(ScreenVis screen) {
		this.vis = screen;
	}
} // end class Screen

/**************************************************************************
 * (C) Copyright 1992-2007 by Deitel & Associates, Inc. and * Pearson Education,
 * Inc. All Rights Reserved. * * DISCLAIMER: The authors and publisher of this
 * book have used their * best efforts in preparing the book. These efforts
 * include the * development, research, and testing of the theories and programs
 * * to determine their effectiveness. The authors and publisher make * no
 * warranty of any kind, expressed or implied, with regard to these * programs
 * or to the documentation contained in these books. The authors * and publisher
 * shall not be liable in any event for incidental or * consequential damages in
 * connection with, or arising out of, the * furnishing, performance, or use of
 * these programs. *
 *************************************************************************/
