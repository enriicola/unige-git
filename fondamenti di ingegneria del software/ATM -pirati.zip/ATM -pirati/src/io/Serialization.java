package io;
import store.BankDatabase;

import com.thoughtworks.xstream.*;
import com.thoughtworks.xstream.io.xml.DomDriver;

//serializza in xml con l'ausilio di xstream
public class Serialization {
	 
	XStream xstream;

    public Serialization(){
         xstream = new XStream(new DomDriver());
         xstream.alias("BankDatabase", BankDatabase.class);
    }

	public BankDatabase deserialize(String f){
		return (BankDatabase)xstream.fromXML(f);
	}
	
	public String serialize(BankDatabase f){
		return xstream.toXML(f);
	}
}
