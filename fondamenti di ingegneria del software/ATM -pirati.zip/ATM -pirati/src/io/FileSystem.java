package io;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

//gestisce input-output con scrittura e lettura su file
public class FileSystem {
	 
	public String readFile(String fName) {
	        String aux = "";
	        try {
	            java.io.File file = new java.io.File(fName);
	            FileInputStream fis = new FileInputStream(file);
	            InputStreamReader isr = new InputStreamReader(fis);
	            BufferedReader br = new BufferedReader(isr);
	            String linea = br.readLine();
	            while (linea != null) {
	                aux = aux.concat(linea + "\n");
	                linea = br.readLine();
	            }
	        } catch (IOException ex) {
	           return null;
	        }
	        return aux;
	    }

	    public boolean saveFile(String fName, String f) {
	        java.io.File file = new java.io.File(fName);
	        FileOutputStream fos;
	        try {
	            fos = new FileOutputStream(file);
	            PrintStream ps = new PrintStream(fos);
	            ps.println(f);
	        } catch (FileNotFoundException e) {
	        	return false;   
	        }
	        return true;
	    }
}
